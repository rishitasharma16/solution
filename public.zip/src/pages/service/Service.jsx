import React from 'react'

function Service() {
  return (
    <div>
      service
    </div>
  )
}

export default Service
