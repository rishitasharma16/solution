import React from 'react'

function PaymentStatus() {
  return (
    <div>
      PaymentStatus
PaymentStatus
    </div>
  )
}

export default PaymentStatus
