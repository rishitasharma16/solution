import React from 'react'

function UserStatus() {
  return (
    <div>
      user staus
    </div>
  )
}

export default UserStatus
