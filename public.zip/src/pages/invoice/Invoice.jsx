import React from 'react'

function Invoice() {
  return (
    <div>
      invoice
    </div>
  )
}

export default Invoice
