import React from 'react'

function Chat() {
  return (
    <div>
      chat
    </div>
  )
}

export default Chat
