import React from 'react'

function ProjectStatus() {
  return (
    <div>
      PaymentStatus
PaymentStatus
    </div>
  )
}

export default ProjectStatus
