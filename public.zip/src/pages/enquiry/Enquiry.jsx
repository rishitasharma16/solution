import React from 'react'
function Enquiry() {
  return (
    <>
   <h1>Enquiry</h1>
    </>
  )
}

export default Enquiry